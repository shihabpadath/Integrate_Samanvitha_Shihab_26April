package com.itc.bandit.bandititcdemo;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MapsActivity extends Activity {

    private GoogleMap mMap; // Might be null if Google Play services APK is not
    // available.
    TextView title, Name;
    ImageView icon;
    private ProgressDialog pDialog;

    // URL to get contacts JSON
    private static String url = "http://54.191.160.210/dummydata.html";

    // local ip :http://10.6.116.208:8080/HelloWorld/

    // JSON Node names
    private static final String TAG_CONTACTS = "contacts";
    private static final String TAG_ID = "id";
    private static final double TAG_LAT = 14.12;

    private static final String TAG_NAME = "name";
    private static final String TAG_EMAIL = "email";
    private static final String TAG_ADDRESS = "address";
    private static final String TAG_GENDER = "gender";
    private static final String TAG_PHONE = "phone";
    private static final String TAG_PHONE_MOBILE = "mobile";
    private static final String TAG_PHONE_HOME = "home";
    private static final String TAG_PHONE_OFFICE = "office";
    HashMap<String, String> contact;
    String url1 = "https://198.20.12.2/";
    String currentloc ;
    //this var is to store current latitude from the GPS
    String[] lat;

    // contacts JSONArray
    JSONArray contacts = null;

    // Hashmap for ListView
    ArrayList<HashMap<String, String>> contactList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        setContentView(R.layout.activity_maphome);
        pDialog = new ProgressDialog(MapsActivity.this);
        contactList = new ArrayList<HashMap<String, String>>();

        new RegisterAsyncTask().execute();
        new DealAccess().execute();

        currentloc=SignIn_Activity.loc;
        lat= currentloc.split(",");

       /* getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.window_title);
        title = (TextView) findViewById(R.id.title);
        icon  = (ImageView) findViewById(R.id.icon);
        this.title.setText(lat[0] + lat[1]);*/


    }

    @Override
    protected void onResume() {
        super.onResume();
        // setUpMapIfNeeded();
    }


    JSONObject json = null;
    private class DealAccess extends AsyncTask<String, String, JSONObject> {

        /**
         * Defining Process dialog
         **/
        private ProgressDialog pDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pDialog = new ProgressDialog(MapsActivity.this);
            pDialog.setTitle("Contacting Servers");
            pDialog.setMessage("Please Wait ...");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();
        }

        @Override
        protected JSONObject doInBackground(String... args) {

            Log.i("MapActivity", "JSONObject doInBackground ");
            JSONParser_Response response = new JSONParser_Response();
            json = response.getJSONFromUrl(url1, lat[0],lat[1], "1");

            return json;


        }
        @Override
        protected void onPostExecute(JSONObject json) {
            /**
             * Checks for success message.
             **/
            Log.i("MapActivity","onPostExecute");
            pDialog.dismiss();

        }
    }




    private class RegisterAsyncTask extends AsyncTask<String, Void, String> {
        Boolean result = true;
        String json = null;

        @Override
        protected void onPreExecute() {
            pDialog.setMessage("Please wait...");
            pDialog.show();
        }

        @SuppressWarnings("deprecation")
        @Override
        protected String doInBackground(String... params) {

            JSONParser jParser = new JSONParser();
            // TODO Auto-generated method stub
            try {
                // http://savmysoul.com/
                // getting JSON string from URL
                json = jParser
                        .getJSONFromUrl("http://54.191.160.210/dummydata.html");

            } catch (Exception e) {
                // TODO: handle exception
                result = false;
                e.printStackTrace();
            }
            return json;
        }

        @Override
        protected void onPostExecute(String result) {

            try {
                if (pDialog.isShowing()) {
                    pDialog.dismiss();
                }
                if (this.result) {
                    parseGmailValidateJSON(result);
                } else {
                    showToast(getString(R.string.server_error));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void parseGmailValidateJSON(String result) {

        // TODO Auto-generated method stub

        try {
            JSONObject jsonObj = new JSONObject(result);

            // Getting JSON Array node
            contacts = jsonObj.getJSONArray(TAG_CONTACTS);

            if (result != null) {
                for (int i = 0; i < contacts.length(); i++) {
                    JSONObject c = contacts.getJSONObject(i);

                    String id = c.getString(TAG_ID);

                    double lat_value = Double.parseDouble(id);
                    String name = c.getString(TAG_NAME);
                    String email = c.getString(TAG_EMAIL);
                    String address = c.getString(TAG_ADDRESS);
                    String gender = c.getString(TAG_GENDER);

                    // Phone node is JSON Object
                    JSONObject phone = c.getJSONObject(TAG_PHONE);
                    String mobile = phone.getString(TAG_PHONE_MOBILE);
                    String home = phone.getString(TAG_PHONE_HOME);
                    String office = phone.getString(TAG_PHONE_OFFICE);

                    // tmp hashmap for single contact
                    contact = new HashMap<String, String>();

                    // adding each child node to HashMap key => value
                    contact.put(TAG_ID, String.valueOf(lat_value));

                    contact.put(TAG_NAME, name);
                    contact.put(TAG_EMAIL, email);
                    contact.put(TAG_PHONE_MOBILE, mobile);

                    // adding contact to contact list
                    contactList.add(contact);

                }

                Log.v("contact", "___contact arraylist value" + contactList);
                Log.v("contact", "___contact hash map value" + contact);

                setUpMapIfNeeded();
            }
            // looping through All Contacts

        } catch (JSONException e) {
            e.printStackTrace();
        }
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

            @Override
            public void onMapClick(LatLng arg0) {
                // TODO Auto-generated method stub
                showToast("please select on any deals");
            }
        });
    }

    private void setUpMapIfNeeded() {
        // Do a null check to confirm that we have not already instantiated the
        // map.
        if (mMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            mMap = ((MapFragment) getFragmentManager().findFragmentById(
                    R.id.map)).getMap();

            // Check if we were successful in obtaining the map.
            if (mMap != null) {
                setUpMap();
            }
        }
    }

    public void showToast(String msg) {
        Toast.makeText(getApplicationContext(), msg,
                Toast.LENGTH_SHORT).show();

    }

    /*
     * marker tutorial
     *
     * https://developers.google.com/maps/documentation/android/marker?hl=FR
     *
     *
     * watch all the map icon related issues...
     */
    private void setUpMap() {

        int[] array_icon = { R.drawable.map_dummy_marker,
                R.drawable.map_dummy_marker, R.drawable.map_dummy_marker,
                R.drawable.map_dummy_marker };
        mMap.addMarker(new MarkerOptions()
                .position(new LatLng(Double.parseDouble(lat[0]),Double.parseDouble(lat[1])))
                .title("Bangalore")
                .icon(BitmapDescriptorFactory
                        .fromResource(R.drawable.current_newicon)));

        CameraUpdate center = CameraUpdateFactory.newLatLng(new LatLng(Double.parseDouble(lat[0]),Double.parseDouble(lat[1])));
        CameraUpdate zoom = CameraUpdateFactory.zoomTo(8);

        mMap.moveCamera(center);
        mMap.animateCamera(zoom);

       /* double[] lat_value = { 27.95, 25.95, 26.95, 22.67 };

        double[] long_value = { 55.33, 54.33, 52.33, 55.73 };
        String[] lativalue = { "", "", "", "", "" };*/

        for (int j = 0; j < contactList.size(); j++) {

            Double.parseDouble(contact.get("id").valueOf(j));

            // Map mTemp=contact.values();

           /* mMap.addMarker(new MarkerOptions()
                    .position(
                            new LatLng(Double.parseDouble(contactList.get(j)
                                    .get("id")), Double.parseDouble(contactList
                                    .get(j).get("name"))))
                    .snippet("Popu: 4,137,400")
                    .icon(BitmapDescriptorFactory.fromResource(array_icon[j])));*/

            mMap.addMarker(new MarkerOptions()
                    .position(
                            new LatLng(Double.parseDouble(lat[0]),Double.parseDouble(lat[1])))
                    .icon(BitmapDescriptorFactory.fromResource(array_icon[j])));

            mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {

                @Override
                public boolean onMarkerClick(Marker arg0) {

                    if(json!=null){
                        Intent i = new Intent(getApplicationContext(),
                                OfferDetailsFragment.class);
                        i.putExtra("offerlist",json.toString());
                        Log.i("MapActivity","json"+json.toString());

                        startActivity(i);
                    }
                    else{
                       Toast.makeText(MapsActivity.this,"No deal at this place",Toast.LENGTH_SHORT).show();
                    }

                    return false;
                }
            });



        }

    }

}
