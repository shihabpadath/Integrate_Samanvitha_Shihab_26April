package com.itc.bandit.bandititcdemo;

import java.util.Timer;
import java.util.TimerTask;

import org.json.JSONArray;

import android.app.ProgressDialog;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.Location;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.location.LocationClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;


public class CurrentlocationService extends Service implements
		LocationListener, GooglePlayServicesClient.ConnectionCallbacks,
		GooglePlayServicesClient.OnConnectionFailedListener {

	private static final String TAG_ID = "spidorlocid";
	private static final String GEO_CODE = "latlang";
	String loc;

	// for testing the location change we are using this counter
	static int mCounter = 1;

	double latitude, longitude, radius, lati, lngi;;

	// -----------------------------------------
	// private GoogleMap mMap;
	private LocationClient mLocationClient;
	private GPSTracker gps;
	private ProgressDialog Dialog;
	private NetworkStatus nw;

	private LayoutInflater inflater;
	private PopupWindow pw;
	private View popupView;
	private Intent startNextActIntent;
	private String LatLon = null, getLocUsername = null, autoCmpTxtStrVal,
			currentLocLatLong, locationNameChar, placeName;
	private int autoCmptxtPos = -1;
	static LatLng currentgeocode = new LatLng(11.013967, 17.5738399);
	static LatLng togeocode = new LatLng(10.013967, 11.5738399);
	private Bundle bundle;
	private LatLng latlang, centerLat = null;
	private String latii, longi, latilongi = null;
	private int posLatLongiVal = -1;
	private JSONArray ja;
	private String[] geoPointArray;
	private Boolean hasSetOnSameLoc = false;
	LatLng position;
	MarkerOptions marker;

	@Override
	public void onCreate() {

		nw = new NetworkStatus(this);
		mLocationClient = new LocationClient(this, this, this);

		if (nw.isOnline()) {
			inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

			try {

				
				getTimer();
				
			

				} catch (Exception e) { // TODO: handle exception
				e.printStackTrace();
			}

			bundle = new Bundle();

			Dialog = new ProgressDialog(this);

		}

		super.onCreate();
	}

	private void callBroadCastReciver() {
		
		IntentFilter filter = new IntentFilter();
		filter.addAction("android.provider.Telephony.SMS_RECEIVED");
		filter.addAction(android.telephony.TelephonyManager.ACTION_PHONE_STATE_CHANGED);
		filter.addAction("your_action_strings"); //further more
		filter.addAction("your_action_strings"); //further more

		Intent map_activty = new Intent(
				CurrentlocationService.this, MapsActivity.class);
		Log.v(" location update", "____location changed" + loc);
		map_activty.putExtra("current_location", loc);
		map_activty.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(map_activty);
		
	//	Toast.makeText(this, "broadcast working", Toast.LENGTH_LONG).show();
		
		Log.v("updating","____updating");
	//	registerReceiver(receiver, filter);
	}

	@Override
	public void onDestroy() {
		
		
		super.onDestroy();
	}

	@Override
	@Deprecated
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub
		super.onStart(intent, startId);
	}

	@Override
	public IBinder onBind(Intent intent) {

		return null;
	}

	public String getGPSCurrentLocation() {
		gps = new GPSTracker(CurrentlocationService.this);

		// check if GPS enabled
		if (gps.canGetLocation()) {
			try {
				double latitude = gps.getLatitude();
				double longitude = gps.getLongitude();

				latii = String.valueOf(latitude);
				longi = String.valueOf(longitude);
				latilongi = latii + "," + longi;
			} catch (Exception e) {
				// TODO: handle exception
			}

		} else {
			try {
				gps.showSettingsAlert();

			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		return latilongi;
	}

	@Override
	public void onConnectionFailed(ConnectionResult arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onConnected(Bundle arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onDisconnected() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onLocationChanged(Location arg0) {
		// TODO Auto-generated method stub

	}

	/*
	 * public void showError(String error) {
	 * 
	 * Toast.makeText(this, error, Toast.LENGTH_LONG).show();
	 * 
	 * }
	 */
	public void getTimer() {
		int delay = 1000; // delay for 1 sec.
		int period = 10000; // repeat every 10 sec.
		Timer timer = new Timer();
		timer.scheduleAtFixedRate(new TimerTask() {
			public void run() {
				String loc_current = loc;
				loc = getGPSCurrentLocation();
				// for testing purpose we are adding extra val to the current
				// gps value
				String[] mCurrLoc = loc.split(",");
				mCounter = mCounter + 4;

				mCurrLoc[0] = String.valueOf((Double.parseDouble(mCurrLoc[0]) + mCounter));
				mCurrLoc[1] = String
						.valueOf((Double.parseDouble(mCurrLoc[1]) + mCounter));
				loc = mCurrLoc[0] + "," + mCurrLoc[1];

				if (!loc.equals(loc_current)) {
/*
					Intent map_activty = new Intent(
							CurrentlocationService.this, MapsActivity.class);
					Log.v(" location update", "____location changed" + loc);
					map_activty.putExtra("current_location", loc);
					map_activty.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(map_activty);*/
					
					callBroadCastReciver();

				} else {

					Log.v(" location update", "____location has no update"
							+ loc);
				}
				// if(loc)
				// need to send the server and incoperted the mapactivty

				Log.v("current location is", "______timer current location"
						+ loc);

			}
		}, delay, period);
	}


}
