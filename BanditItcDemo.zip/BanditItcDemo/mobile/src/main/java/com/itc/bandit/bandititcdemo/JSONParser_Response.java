package com.itc.bandit.bandititcdemo;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

public class JSONParser_Response {

    static InputStream is = null;
    static JSONObject jObj = null;
    static String json = "";
    JSONArray Deals;

    // constructor
    public JSONParser_Response() {

    }

    public JSONObject getJSONFromUrl(String url, String lat,String longi, String pref_id) {

   
    	
    	 InputStream inputStream = null;
         String result = "";
         try {

             // 1. create HttpClient
             HttpClient httpclient = new DefaultHttpClient();

             // 2. make POST request to the given URL
             HttpPost httpPost = new HttpPost(url);

             String json = "";

             // 3. build jsonObject
             JSONObject jsonObject = new JSONObject();
             jsonObject.accumulate("Lat","");
             jsonObject.accumulate("Long", "");
             jsonObject.accumulate("Pref_ID", "");
             
             // 4. convert JSONObject to JSON to String
             json = jsonObject.toString();

             // 5. set json to StringEntity
             StringEntity se = new StringEntity(json);

             // 6. set httpPost Entity
             httpPost.setEntity(se); 

             // 7. Set some headers to inform server about the type of the content   
             httpPost.setHeader("Accept", "application/json");
             httpPost.setHeader("Content-type", "application/json");

             // 8. Execute POST request to the given URL
             HttpResponse httpResponse = httpclient.execute(httpPost);

             // 9. receive response as inputStream
             inputStream = httpResponse.getEntity().getContent();

             // 10. convert inputstream to string
             if(inputStream != null){
                 result = convertInputStreamToString(inputStream);
                 json=result;
                 jObj = new JSONObject(json);
             Log.i("getJSONFromUrl", "result " + result);
             }
             else
                 result = "No Deals Avaliable";
             Log.i("getJSONFromUrl", "result " + result);

         } catch (Exception e) {
             Log.e("InputStream", "error from network is:"+e.getLocalizedMessage());
             if(!result.equalsIgnoreCase("")){
            	 //result = "['Deal_Master:'{'Deal_ID':'1','Deal_Name':'Allen Solly','Deal_Description':'Top','Deal_Image':' ','Pref_ID':'1','Lat':'','Long':'','Modified_By':' ','Modified_On':''}+{'Deal_ID':'1','Deal_Name':'Allen Solly','Deal_Description':'Top','Deal_Image':' ','Pref_ID':'1','Lat':'','Long':'','Modified_By':' ','Modified_On':''}"+"{'Deal_ID':'1','Deal_Name':'Allen Solly','Deal_Description':'Top','Deal_Image':' ','Pref_ID':'1','Lat':'','Long':'','Modified_By':' ','Modified_On':''}]";
            	 String[] mTempData={"Allen Solly","rebook","Adidas","Puma","Lenovo","Starbucks","Pizza","Caffe bugutee"};
            	 JSONObject[] jo = new JSONObject[8];
            	 JSONArray ja = new JSONArray();
            	 try {
            		 for(int i=0;i<8;i++){
            	   jo[i]=new JSONObject();
            		jo[i].put("Deal_ID", "1");
					jo[i].put("Deal_Name", mTempData[i]);
					jo[i].put("Deal_Description", "Top");
					jo[i].put("Deal_Image", "");
					jo[i].put("Pref_ID", "1");
					jo[i].put("Lat", "1");
					jo[i].put("Long", "1");
					jo[i].put("Modified_By", "1");
					jo[i].put("Modified_On", "1");
					
					ja.put(jo[i]);
					
					
	            	 
            		 }
            		 
	            	 JSONObject mainObj = new JSONObject();
	            	 mainObj.put("Deal_Master", ja);
	            	 result=mainObj.toString();
				} catch (JSONException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

            	 
             }
         }

         try {
        	 json=result;
        	 Log.i("getJSONFromUrl","json result"+json);
             jObj = new JSONObject(json);
            // Deals=new JSONArray(json);
         } catch (JSONException e) {
             Log.i("getJSONFromUrl", "Error parsing data " + e.toString());
            
         }

         // return JSON String
         return jObj;
     }
    
    private static String convertInputStreamToString(InputStream inputStream) throws IOException{
        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;

    }   

    
}
