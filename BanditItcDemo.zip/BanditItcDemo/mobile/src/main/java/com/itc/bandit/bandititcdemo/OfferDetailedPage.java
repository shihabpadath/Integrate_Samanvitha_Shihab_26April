package com.itc.bandit.bandititcdemo;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.itc.bandit.bandititcdemo.R;




public class OfferDetailedPage extends Activity {

	ImageView Offer_image;
	TextView Offer_name,Offer_percentage,Cost;
	Button Store_call, Redeem, Navigate;
	String name;
	
	TextView title, Name;
	 ImageView icon; 
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);

		setContentView(R.layout.offer_detailed);
		
		Name = (TextView)findViewById(R.id.brand_name);
		
		Bundle extras = getIntent().getExtras();
		name = extras.getString("name");
	    /* inputString = extras.getString("name");
	     inputString = extras.getString("name");
	     inputString = extras.getString("name");
	     inputString = extras.getString("name");
	     inputString = extras.getString("name");*/
	    Log.i("OfferDetailedPage","inputString "+ name);
	    
	   /* getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.window_title);
        title = (TextView) findViewById(R.id.title);
        icon  = (ImageView) findViewById(R.id.icon);
	this.title.setText(name);*/
	//this.icon.setImageResource(R.drawable.menu_news);
	Name.setText(name+" 20% Off");

	}

	@Override
	protected void onResume() {
		super.onResume();

	}

}
