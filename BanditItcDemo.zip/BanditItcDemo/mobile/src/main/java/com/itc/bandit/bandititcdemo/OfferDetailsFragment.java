package com.itc.bandit.bandititcdemo;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;


@SuppressLint("NewApi")
public class OfferDetailsFragment extends Activity {
	
	ListView list;
	String[] string_array;
	 String inputString;
	 JSONArray deals = null;

    TextView title, Name;
    ImageView icon;

	// String[] web1 = new String[];
	 ArrayList<String> address=new ArrayList<String>();
	 ArrayList<String> web=new ArrayList<String>();
	 ArrayList<String> offer_percent=new ArrayList<String>();
	 ArrayList<String> imageId=new ArrayList<String>();
	 ArrayList<String> duration=new ArrayList<String>();
	// Current Location Details :

	public OfferDetailsFragment() {
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {

		Bundle extras = getIntent().getExtras();
	     inputString = extras.getString("offerlist");
	    Log.i("OfferDetailedPage","inputString "+ inputString);

		super.onCreate(savedInstanceState);
       // requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.offer_details);

       /* getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.window_title);
        title = (TextView) findViewById(R.id.title);
        icon  = (ImageView) findViewById(R.id.icon);
        this.title.setText("Offers List");*/

		/*String[] web = { "30 Mortensen Avenue Salinas CA 93905","200 Lincoln Ave Salinas CA 93901","65 West Alisal Salinas CA 93901",
				"111 Grand Ave P.O. Box 23660 Oakland CA 94623", "50 Higuera Street San Luis Obispo CA 93401", "30 Mortensen Avenue Salinas CA 93905 ", "200 Lincoln Ave Salinas CA 93901","65 West Alisal Salinas CA 93901",
				"111 Grand Ave P.O. Box 23660 Oakland CA 94623", "50 Higuera Street San Luis Obispo CA 93401","30 Mortensen Avenue Salinas CA 93905 "};

		String[] doctor_address = { "Puma", "Starbucks", "Costa Coffee", "Allen Solly",
				"Reebok", "Samsung", "van Heusen","Cafe Coffee Day", "CODE", "Adidas", "Iphone"};
		
		String[] offer_percent = { "20% OFF on sandals", "40% OFF on Latte", "10 %OFF on Breakfast", "60% OFF on Men Shirts",
				"10% OFF on shoes", "5% OFF Galaxy Note", "10% OFF on women wear","20% OFF on Eskimo Cold Coffee", "50% Flat", "13% OFF on Bags", "10% OFF on Iphone5"};

		Integer[] imageId = { R.drawable.sandals_offer, R.drawable.coffe_maker,
				R.drawable.coffe_maker_offer, R.drawable.cloth_discount,
				R.drawable.sandals_offer, R.drawable.yellow_phone,
				R.drawable.cloth_sample, R.drawable.coffe_maker,
				R.drawable.cloth_discount, R.drawable.sandals_offer,
				R.drawable.yellow_phone };
		
		String[] duration = {"0.2","0.3","0.1","1","0.5","2","0.2","0.1","0.2","0.3","0.5"};*/

		// curent location
		
		
		try {
            JSONObject jsonObj = new JSONObject(inputString);
             
            // Getting JSON Array node
            deals = jsonObj.getJSONArray("Deal_Master");

            // looping through All Contacts
            for (int i = 0; i < deals.length(); i++) {
                JSONObject c = deals.getJSONObject(i);
                 
                String id = c.getString("Deal_ID");
                String name = c.getString("Deal_Name");
                String Desc = c.getString("Deal_Description");
                String image = c.getString("Deal_Image");
                String pref = c.getString("Pref_ID");
                String lat = c.getString("Lat");
                String longi = c.getString("Long");

                address.add(name);
                offer_percent.add(Desc);
                web.add("Avenue Salinas CA 93905");
                duration.add("0.2");
                imageId.add(" ");
                
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
		
		
		

		OfferAdapter adapter = new OfferAdapter(this,address,web,offer_percent,
				imageId,duration);
		list = (ListView) findViewById(R.id.offer_list);
		

		list.setAdapter(adapter);

		// locationShowAlert();

		list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				
				Intent offer_detailed=new Intent(OfferDetailsFragment.this,OfferDetailedPage.class);
				
				offer_detailed.putExtra("name", address.get(position));
				offer_detailed.putExtra("Desc",offer_percent.get(position));
				offer_detailed.putExtra("address", web.get(position));
				offer_detailed.putExtra("time", duration.get(position));
				offer_detailed.putExtra("image", imageId.get(position));
				startActivity(offer_detailed);

			}
		});

	}
}
